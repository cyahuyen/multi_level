<form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr">
                        <input type="hidden" name="cmd" value="_xclick">
                        <input type="hidden" name="business" value="thuhuy_1317911597_per@gmail.com">
                        <input type="hidden" name="amount" value="0.1">           
                        <input type="hidden" name="item_name" value="CYA Game payment">
                        <input type="hidden" name="currency_code" value="USD">
                        <input type="hidden" name="no_shipping" value="2">
                        <input type="hidden" name="no_note" value="1">
                        <input type="hidden" name="mrb" value="3FWGC6LFTMTUG">
                        <input type="hidden" name="bn" value="IC_Sample">
                        <input type="hidden" name="return" value="http://multilevel.lc/test.php"> 
                        <input type="hidden" name="cancel_return" value="http://multilevel.lc/index.php/adminmodule/">
                        <input type="hidden" name="notify_url" value="http://multilevel.lc/test.php">
                        <input type="hidden" name="cbt" value="Continue">
                        <input type="hidden" name="rm" value="2">
                        
                          <input type="submit" value="Confirm">
                            
</form>