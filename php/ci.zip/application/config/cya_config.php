<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$config['public_key'] = '6Lc4gN0SAAAAADHAXwXKEK-hVcSmpDziBYZMfjZ_';
$config['private_key'] = '6Lc4gN0SAAAAADWro91z6JFCCPNKqKAIix_pTTjG';
$config['domain'] = 'dll2.lc';
?>