<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$config['site_name'] = 'WM Loud Plant and Equipment Management';
$config['site_admin'] = 'dean.gleeson@pragmaticsystems.com.au';
$config['system_mail'] = 'noreply@pragmaticsystems.com.au';

$config["datalist_default_pagesize"] = 20;
$config['limit_page'] = 20;
$config['prefix_key'] = '895738llnjdy8p';

?>