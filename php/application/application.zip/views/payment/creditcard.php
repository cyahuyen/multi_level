

<tr>
    <td colspan="">Credit Card</td>
    <td>
        <input type="radio"  name="payment" id="payment" value="creditcard"/> Credit Card
    </td>
</tr>
<tr class="creditcard">
    <td >Card Owner</td>
    <td>
        <input type="text"  name="cc_owner" id="cc_owner" value=""/> 
    </td>
</tr>
<tr class="creditcard">
    <td>Card Number</td>
    <td>
        <input type="text" name="card_num" id="card_num" style="width:300px">
    </td>
</tr>
<tr class="creditcard">
    <td>Exp Date</td>
    <td>
        <input type="text" name="exp_date" id="exp_date" style="width:300px">
    </td>
</tr>
<tr class="creditcard">
    <td>CVV2</td>
    <td>
        <input type="text" name="cc_cvv2" id="cc_cvv2" style="width:300px">
    </td>
</tr>


