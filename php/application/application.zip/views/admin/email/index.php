<div id="content-header">


    <div class="content-header">
        <div class="content-title">
            <h1>Manage Users</h1>
        </div>
        <div class="content-actions">
            <div class="content-action">
                <div class="clear"><a href="javascript:void(0);" onclick="window.location='<?php echo admin_url('email/profile') ?>'"><img src="<?php echo base_url() ?>/img/actions/add.png" alt="Save Continue"></a></div>
                <div class="clear"><span>Add</span></div>
            </div>
        </div>
    </div>

</div>