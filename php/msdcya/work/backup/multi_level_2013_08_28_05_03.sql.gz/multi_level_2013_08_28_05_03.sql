-- Status:15:85:MP_0:multi_level:php:1.24.4::5.5.16:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|activity|0|16384||InnoDB
-- TABLE|answer|0|16384||InnoDB
-- TABLE|balance|8|16384||InnoDB
-- TABLE|balance_history|0|16384||InnoDB
-- TABLE|config|46|16384||InnoDB
-- TABLE|email_template|18|65536||InnoDB
-- TABLE|multilevel_sessions|4|32768||InnoDB
-- TABLE|payment_history|0|16384||InnoDB
-- TABLE|question|0|16384||InnoDB
-- TABLE|tmp_info|2|16384||InnoDB
-- TABLE|transaction|0|16384||InnoDB
-- TABLE|user|1|16384||InnoDB
-- TABLE|user_main|1|16384||InnoDB
-- TABLE|users_groups|3|16384||InnoDB
-- TABLE|users_permission|2|16384||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-08-28 05:03

--
-- Create Table `activity`
--

DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `main_user_id` int(10) NOT NULL,
  `created` datetime NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `activity`
--

/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;


--
-- Create Table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `question_id` int(10) NOT NULL,
  `answer_content` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `answer`
--

/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;


--
-- Create Table `balance`
--

DROP TABLE IF EXISTS `balance`;
CREATE TABLE `balance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `balance` double(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Data for Table `balance`
--

/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('1','1','-37420.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('2','7','1500.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('3','8','500.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('4','9','115.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('5','12','5.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('6','11','300.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('7','10','41975.00');
INSERT INTO `balance` (`id`,`user_id`,`balance`) VALUES ('8','13','200.00');
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;


--
-- Create Table `balance_history`
--

DROP TABLE IF EXISTS `balance_history`;
CREATE TABLE `balance_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `balance` double(10,4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `balance_history`
--

/*!40000 ALTER TABLE `balance_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance_history` ENABLE KEYS */;


--
-- Create Table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `group` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `key` varchar(200) NOT NULL,
  `value` text,
  `serialized` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=368 DEFAULT CHARSET=latin1;

--
-- Data for Table `config`
--

/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('234','config','referraldefault','default_referral_user','U1369627271','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('235','config','timeconfig','time_format','30','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('263','config','emails','protocol','mail','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('264','config','emails','mail_parameter','','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('265','config','emails','smtp_host','ssl://smtp.googlemail.com','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('266','config','emails','smtp_user','rongandat@gmail.com','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('267','config','emails','smtp_pass','anhyeuem123','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('268','config','emails','smtp_port','465','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('269','config','emails','smtp_timeout','30','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('270','config','emails','email_admin','admin@gmail.com','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('271','config','emails','group','config','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('272','config','withdrawal','days_space_gold','365','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('273','config','withdrawal','days_space_silver','60','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('274','config','withdrawal','min_of_gold','50','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('275','config','withdrawal','min_of_silver','20','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('276','config','withdrawal','group','config','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('279','config','levelupdate','level_update','6','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('321','config','transaction_fees','open_fee','25','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('322','config','transaction_fees','transaction_fee','10','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('323','config','transaction_fees','min_enrolment_entry_amount','100','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('324','config','transaction_fees','max_enrolment_entry_amount','500','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('325','config','transaction_fees','max_enrolment_silver_amount','100','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('326','config','transaction_fees','group','config','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('327','config','referral','percentage_gold','5','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('328','config','referral','bonus_percentage_silver','2','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('329','config','referral','bonus_percentage_gold','5','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('330','config','referral','percent_referral_fees','15','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('331','config','referral','referral_fees','5','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('332','config','referral','referral_bonus_default','25','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('333','config','referral','referral_bonus','a:6:{i:1;a:3:{s:3:\"min\";s:1:\"1\";s:3:\"max\";s:1:\"5\";s:6:\"refere\";s:2:\"50\";}i:2;a:3:{s:3:\"min\";s:1:\"6\";s:3:\"max\";s:2:\"10\";s:6:\"refere\";s:2:\"55\";}i:3;a:3:{s:3:\"min\";s:2:\"11\";s:3:\"max\";s:2:\"15\";s:6:\"refere\";s:2:\"60\";}i:4;a:3:{s:3:\"min\";s:2:\"16\";s:3:\"max\";s:2:\"20\";s:6:\"refere\";s:2:\"65\";}i:5;a:3:{s:3:\"min\";s:2:\"21\";s:3:\"max\";s:2:\"25\";s:6:\"refere\";s:2:\"70\";}i:6;a:3:{s:3:\"min\";s:2:\"25\";s:3:\"max\";s:0:\"\";s:6:\"refere\";s:3:\"100\";}}','1');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('334','payment','paypal','business','thuhuy_1317911597_per@gmail.com','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('335','payment','paypal','item_name','CYA Game payment','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('336','payment','paypal','currency_code','USD','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('337','payment','paypal','sandbox','1','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('351','payment','creditcard','title','Credit Card','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('352','payment','creditcard','login_id','6Z2Kgs6W7m','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('353','payment','creditcard','transaction','49yh68ESgd4Sd2Mw','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('354','payment','creditcard','authorizenet_aim_method','authorization','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('355','payment','creditcard','sandbox','1','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('356','payment','creditcard','active','1','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('362','payment','aw_quickpay','title','Allied Wallet QuickPay','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('363','payment','aw_quickpay','site','safeco-op.com','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('364','payment','aw_quickpay','MerchantID','c22d8c35-0af6-463b-9180-c57642039e88','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('365','payment','aw_quickpay','SiteID','a3d993b1-b997-4f66-90a5-79ff2240815f','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('366','payment','aw_quickpay','aw_currency','USD','0');
INSERT INTO `config` (`id`,`group`,`code`,`key`,`value`,`serialized`) VALUES ('367','payment','aw_quickpay','active','1','0');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;


--
-- Create Table `email_template`
--

DROP TABLE IF EXISTS `email_template`;
CREATE TABLE `email_template` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(200) NOT NULL,
  `subject` varchar(400) NOT NULL,
  `content` text NOT NULL,
  `slug` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Data for Table `email_template`
--

/*!40000 ALTER TABLE `email_template` DISABLE KEYS */;
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('1','deposite','Have just new member deposite','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><strong>Full Name</strong>: {{full_name}}</span></p>\r\n<p><strong>Email</strong>: {{email}}</p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><strong>Amount</strong>: {{amount}}<br /></span></p>','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{</span><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">full_name</span>}}: Full name<br /></span></p>\r\n<p>{{email}}: Email</p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{</span><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">amount</span>}}: Amount<br /></span></p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('2','register','Thank you for registering','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Thank you for registering.</span><br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">You just sign up at. Please login to check your account.<br /></span></p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Payment :{{entry_amount}}</span></p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Fees: {{fees}}</span></p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">password: {{password}}</span></p>','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{</span><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">entry_amount</span>}}: Amount Register</span></p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{password}}: Password</span></p>\r\n<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{fees}} :Fees</span></p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('3','admin_register','Have just new member register','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Have just new member register</span><br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Full name: {{fullname}}</span><br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Address:</span>{{address}}<br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Phone:</span>{{phone}}<br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">Email:<span class=\"Apple-converted-space\"> {{email}}</span></span><br style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff;\" /><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">payment: {{payment}}</span></p>','<p><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">{{</span><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\">fullname</span>}} : Fullname<br /></span></p>\r\n<p>{{address}} :Adress</p>\r\n<p>{{phone}}: Phone</p>\r\n<p>{{<span style=\"color: #222222; font-family: arial, sans-serif; font-size: 13px; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-size-adjust: auto; -webkit-text-stroke-width: 0px; background-color: #ffffff; display: inline !important; float: none;\"><span class=\"Apple-converted-space\">email</span></span>}}<span class=\"Apple-converted-space\">: Email</span></p>\r\n<p>{{payment}}: Payment</p>\r\n<p>&nbsp;</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('4','referring','Your referring member','<p>Your referring member {{fullname}} just sign up at.</p>','<p>{{fullname}} : Fullname</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('5','forgot_password','Forgot Password','<p>Code forget Password: {{forget_code}}</p>','<p>{{forget_code}} : Code</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('6','user_expiration','Users Expiration!','<p>Gold account {{fullname}}&nbsp; has expired.</p>','<p>{{fullname}} : Fullname</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('7','acount_expiration','Account Expiration!','<p>Your Gold account has expired. Your current account type is {{user_type}}. Please log in and deposite to be Gold again.</p>','<p>{{user_type}} : User Type</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('8','profit','Profit month {{month}}','<p>You have just received: {{blance_fees}} month {{month}}</p>\r\n<p>Acount number: {{acount_number}}</p>','<p>{{month}}: month</p>\r\n<p>{{blance_fees}}: Blance Fees</p>\r\n<p>{{acount_number}}: acount number</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('9','admin_withdrawal','Withdrawal','<p><strong>Fullname:&nbsp;</strong>{{fullname}}</p>\r\n<p><strong>AcountNumber:&nbsp;</strong>{{username}}</p>\r\n<p><strong>Email:&nbsp;</strong>{{email}}</p>\r\n<p><strong>Email paypal:&nbsp;</strong>{{email_paypal}}</p>\r\n<p><strong>Amount:&nbsp;</strong>{{amount}}</p>','<p>{{fullname}} : Fullname</p>\r\n<p>{{username}}: AcountNumber</p>\r\n<p>{{email}}: Email</p>\r\n<p>{{email_paypal}}: Email paypal</p>\r\n<p>{{amount}}: Amount</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('10','payment_sucess','Payment Success','<p>Hi {{fullname}}</p>\r\n<p>Amount: {{amount}}</p>','<p>{{amount}}: Amount</p>\r\n<p>{{fullname}}: Fullname</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('11','referring_deposit','You have just referring deposit','<p>hi {{fullname}}!</p>\r\n<p>You have just ${{amount}} from {{user_fullname}}</p>','<p>{{fullname}} : Fullname referring user</p>\r\n<p>{{user_fullname}} : Deposit user</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('12','user_withdrawal','Withdrawal','<p>Hi<strong>&nbsp;</strong>{{fullname}}!</p>\r\n<p><strong>Email paypal:&nbsp;</strong>{{email_paypal}}</p>\r\n<p><strong>Amount: $</strong>{{amount}}</p>\r\n<p><strong>Fees</strong>: ${{fees}}</p>\r\n<p><strong>Total</strong>: ${{total}}</p>','<p>{{email_paypal}}: Email paypal</p>\r\n<p>{{amount}}: Amount</p>\r\n<p>{{fees}}:Fees</p>\r\n<p>{{total}} : Total</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('13','payment_cancel','Withdrawal Cancel','<p><strong><br /></strong>Hi {{fullname}}!</p>\r\n<p><strong>Amount</strong> :{{amount}}</p>','<p>{{fullname}}:Full name</p>\r\n<p>{{amount}} : Amount</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('14','admin_profit','Profit','<p>{{content}}</p>','<p>{{content}} :Content Email</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('15','update_question','Update Question','<p>Hi {{fullname}}!</p>\r\n<p>You have just updated question \"{{question}}\"</p>','<p>{{fullname}} : Fullname</p>\r\n<p>{{question}} : Question name</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('16','add_question','Add question','<p>Hi {{fullname}}!</p>\r\n<p>You have just add question \"{{question}}\"</p>\r\n<p>We will reply you as soon as possible</p>','<p>{{fullname}} : Fullname</p>\r\n<p>{{question}} : Question name</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('17','admin_add_question','Question \"{{question}}\"','<p>{{fullname}} have just sent you a question \"{{question}}\"</p>','<p>{{fullname}} : Fullname</p>\r\n<p>{{question}} : Question name</p>');
INSERT INTO `email_template` (`id`,`code`,`subject`,`content`,`slug`) VALUES ('18','add_answer_admin','Answer of question {{question}}','<p>hi {{fullname}}</p>\r\n<p>Admin answered \"{{question}}\"</p>\r\n<p>&nbsp;</p>','<p>{{fullname}} : Fullname</p>\r\n<p>{{question}}: Question</p>');
/*!40000 ALTER TABLE `email_template` ENABLE KEYS */;


--
-- Create Table `multilevel_sessions`
--

DROP TABLE IF EXISTS `multilevel_sessions`;
CREATE TABLE `multilevel_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `multilevel_sessions`
--

/*!40000 ALTER TABLE `multilevel_sessions` DISABLE KEYS */;
INSERT INTO `multilevel_sessions` (`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`,`created`) VALUES ('448fa3d6e250e502649e71e98b3f1fac','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0 FirePHP/0.7.2','1377658141','a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"register_info\";s:344:\"eyJ1c2VybmFtZSI6InJvbmdhbmRhdCIsInBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJyZXBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJmaXJzdG5hbWUiOiJLaGllbSIsImxhc3RuYW1lIjoiUGhhbSIsImFkZHJlc3MiOiJIYSBOb2kiLCJwaG9uZSI6IjAxMjI1NTU4ODgiLCJlbWFpbCI6InJvbmdhbmRhdEBnbWFpbC5jb20iLCJyZWZlcnJpbmciOiIiLCJlbnRyeV9hbW91bnQiOiIxMDAiLCJwYXltZW50IjoiYXdfcXVpY2twYXkiLCJzYXZlLWJ0biI6IlNhdmUifQ==\";}','0000-00-00 00:00:00');
INSERT INTO `multilevel_sessions` (`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`,`created`) VALUES ('58a9900c4c1b2f5e61ea6c331042a47d','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0','1377657631','a:3:{s:9:\"user_data\";s:0:\"\";s:4:\"user\";a:6:{s:7:\"main_id\";s:1:\"1\";s:9:\"firstname\";s:4:\"admn\";s:8:\"lastname\";s:5:\"admin\";s:5:\"email\";s:15:\"admin@gmail.com\";s:6:\"status\";s:1:\"1\";s:10:\"permission\";s:13:\"administrator\";}s:21:\"flash:old:usermessage\";a:4:{i:0;s:7:\"success\";i:1;s:5:\"green\";i:2;s:19:\"Successfully saved \";i:3;s:0:\"\";}}','0000-00-00 00:00:00');
INSERT INTO `multilevel_sessions` (`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`,`created`) VALUES ('bfd9a258c78d32ad180147264c51ba58','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0 FirePHP/0.7.2','1377577535','a:1:{s:13:\"register_info\";s:340:\"eyJ1c2VybmFtZSI6InJvbmdhbmRhdCIsInBhc3N3b3JkIjoiMTExMTExIiwicmVwYXNzd29yZCI6IjExMTExMSIsImZpcnN0bmFtZSI6IktoaWVtIiwibGFzdG5hbWUiOiJQaGFtIiwiYWRkcmVzcyI6IkhhIE5vaSIsInBob25lIjoiMDE2OTQwNDY2MjciLCJlbWFpbCI6ImtoaWVta3RxZEBnbWFpbC5jb20iLCJyZWZlcnJpbmciOiIiLCJlbnRyeV9hbW91bnQiOiIxMDAiLCJwYXltZW50IjoiYXdfcXVpY2twYXkiLCJzYXZlLWJ0biI6IlNhdmUifQ==\";}','0000-00-00 00:00:00');
INSERT INTO `multilevel_sessions` (`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`,`created`) VALUES ('d3fdb50ca52d4efaa3a54a20f03d43b2','127.0.0.1','Mozilla/5.0 (Windows NT 6.1; rv:23.0) Gecko/20100101 Firefox/23.0','1377576398','','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `multilevel_sessions` ENABLE KEYS */;


--
-- Create Table `payment_history`
--

DROP TABLE IF EXISTS `payment_history`;
CREATE TABLE `payment_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `total` double(10,4) NOT NULL,
  `fees` double(10,4) NOT NULL,
  `email_paypal` varchar(200) DEFAULT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `confirm_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `payment_history`
--

/*!40000 ALTER TABLE `payment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_history` ENABLE KEYS */;


--
-- Create Table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `main_user_id` int(10) NOT NULL,
  `title` varchar(300) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `admin_status` tinyint(4) NOT NULL DEFAULT '0',
  `user_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `question`
--

/*!40000 ALTER TABLE `question` DISABLE KEYS */;
/*!40000 ALTER TABLE `question` ENABLE KEYS */;


--
-- Create Table `tmp_info`
--

DROP TABLE IF EXISTS `tmp_info`;
CREATE TABLE `tmp_info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tmp_info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Data for Table `tmp_info`
--

/*!40000 ALTER TABLE `tmp_info` DISABLE KEYS */;
INSERT INTO `tmp_info` (`id`,`tmp_info`) VALUES ('1','eyJ1c2VybmFtZSI6InJvbmdhbmRhdCIsInBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJyZXBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJmaXJzdG5hbWUiOiJLaGllbSIsImxhc3RuYW1lIjoiUGhhbSIsImFkZHJlc3MiOiJIYSBOb2kiLCJwaG9uZSI6IjAxMjI1NTU4ODgiLCJlbWFpbCI6InJvbmdhbmRhdEBnbWFpbC5jb20iLCJyZWZlcnJpbmciOiIiLCJlbnRyeV9hbW91bnQiOiIxMDAiLCJwYXltZW50IjoiYXdfcXVpY2twYXkiLCJzYXZlLWJ0biI6IlNhdmUifQ==');
INSERT INTO `tmp_info` (`id`,`tmp_info`) VALUES ('2','eyJ1c2VybmFtZSI6InJvbmdhbmRhdCIsInBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJyZXBhc3N3b3JkIjoiYW5oeWV1ZW0iLCJmaXJzdG5hbWUiOiJLaGllbSIsImxhc3RuYW1lIjoiUGhhbSIsImFkZHJlc3MiOiJIYSBOb2kiLCJwaG9uZSI6IjAxMjI1NTU4ODgiLCJlbWFpbCI6InJvbmdhbmRhdEBnbWFpbC5jb20iLCJyZWZlcnJpbmciOiIiLCJlbnRyeV9hbW91bnQiOiIxMDAiLCJwYXltZW50IjoiYXdfcXVpY2twYXkiLCJzYXZlLWJ0biI6IlNhdmUifQ==');
/*!40000 ALTER TABLE `tmp_info` ENABLE KEYS */;


--
-- Create Table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE `transaction` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `main_user_id` int(10) NOT NULL,
  `fees` double(10,2) NOT NULL DEFAULT '0.00',
  `total` double(10,2) NOT NULL DEFAULT '0.00',
  `created` datetime DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `transaction_type` varchar(500) DEFAULT NULL,
  `transaction_text` varchar(5) DEFAULT '+',
  `transaction_source` varchar(100) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `transaction`
--

/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;


--
-- Create Table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `main_user_id` int(10) NOT NULL DEFAULT '0',
  `acount_number` varchar(200) COLLATE utf16_bin NOT NULL,
  `usertype` int(11) DEFAULT NULL,
  `withdrawal_date` date DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Data for Table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`,`main_user_id`,`acount_number`,`usertype`,`withdrawal_date`,`created`) VALUES ('1','1','','-1',NULL,'2013-08-22 00:00:00');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Create Table `user_main`
--

DROP TABLE IF EXISTS `user_main`;
CREATE TABLE `user_main` (
  `main_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `main_account_number` varchar(200) NOT NULL,
  `address` text,
  `referring` int(10) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `forgotten_password_code` varchar(300) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `permission` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`main_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `user_main`
--

/*!40000 ALTER TABLE `user_main` DISABLE KEYS */;
INSERT INTO `user_main` (`main_id`,`username`,`firstname`,`lastname`,`email`,`password`,`main_account_number`,`address`,`referring`,`phone`,`status`,`forgotten_password_code`,`created_on`,`permission`) VALUES ('1','administrator','admn','admin','admin@gmail.com','e10adc3949ba59abbe56e057f20f883e','','',NULL,'','1',NULL,'0000-00-00 00:00:00','administrator');
/*!40000 ALTER TABLE `user_main` ENABLE KEYS */;


--
-- Create Table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `user_id` int(8) unsigned NOT NULL,
  `permission_id` int(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `users_groups`
--

/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` (`id`,`user_id`,`permission_id`) VALUES ('1','1','1');
INSERT INTO `users_groups` (`id`,`user_id`,`permission_id`) VALUES ('2','2','2');
INSERT INTO `users_groups` (`id`,`user_id`,`permission_id`) VALUES ('3','3','2');
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;


--
-- Create Table `users_permission`
--

DROP TABLE IF EXISTS `users_permission`;
CREATE TABLE `users_permission` (
  `permission_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `users_permission`
--

/*!40000 ALTER TABLE `users_permission` DISABLE KEYS */;
INSERT INTO `users_permission` (`permission_id`,`name`,`description`) VALUES ('1','adminstrator','Supper Administrator');
INSERT INTO `users_permission` (`permission_id`,`name`,`description`) VALUES ('2','moderator','Moderator');
/*!40000 ALTER TABLE `users_permission` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

